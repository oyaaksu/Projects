// makeGrid function uses the input values to create a table after
// clearing existing table.
$(document).ready(function () {  // Grid generation based on user input
    $('#sizePicker').submit(function makeGrid(grid) {
    $('table tr').remove(); // Clearing existing table.
    var rows = $('#inputHeight').val();
    var columns = $('#inputWidth').val();
    for (var i = 1; i <= rows; i++) {
        $('table').append("<tr></tr>");
        for (var j = 1; j <= columns; j++) {
            $('tr:last').append("<td></td>");
            $('td').attr("class", 'cells');
        }
      }
      grid.preventDefault();
      $('.cells').click(function(event) { // Updates the value of color when user selects new color from palette.
        var color = $('#colorPicker').val();
        $(event.target).css('background-color', color);
      });
    });
  });
