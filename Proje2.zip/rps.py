
""""
Created on Mon Oct 12 18:23:32 2020

@author: OYA AKSU
"""
""" first_player --> Human Player """
""" second_player --> Random Player"""


"""This program plays a game of Rock, Paper, Scissors between two Players,
and reports both Player's scores each round."""


"""The Player class is the parent class for all of the Players
in this game"""




import random

class Player:
    moves = ['rock', 'paper', 'scissors']

    def __init__(self):
        self.first_player = self.moves
        self.second_player = random.choice(self.moves)

    def learn(self, first_player, second_player):
        self.first_player = first_player
        self.second_player = second_player


class RandomPlayer(Player):
    def move(self):
        return random.choice(self.moves)

class ReflectPlayer(Player):
    def move(self):
        return self.second_player


class CyclePlayer(Player):
    def move(self):
        if self.first_player == self.moves[0]:
            return self.moves[1]
        elif self.first_player == self.moves[1]:
            return self.moves[2]
        else:
            return self.moves[0]


class HumanPlayer(Player):
    def move(self):
        while True:
            move_human = input("Rock, Paper, Scissors? > ")
            if move_human.lower() in self.moves:
                return move_human.lower()
            elif move_human.lower() == 'exit':
                exit()


class Game:
    def __init__(self, p1, p2):
        self.p1 = p1
        self.p2 = p2
        self.score_p1 = 0
        self.score_p2 = 0

    def beats(self, one, two):
        return ((one == 'rock' and two == 'scissors') or
                (one == 'scissors' and two == 'paper') or
                (one == 'paper' and two == 'rock'))

    def rounds(self):
        while True:
            self.number_rounds = input(
                "How many rounds do you want to play? > ")
            if self.number_rounds.isdigit():
                return self.number_rounds
            elif self.number_rounds.lower() == 'exit':
                exit()

    def play_round(self):
        move1 = self.p1.move()
        move2 = self.p2.move()
        if self.beats(move1, move2):
            self.score_p1 += 1
            winner = '*** PLAYER ONE WINS ***'
        elif move1 == move2:
            self.score_p1 = self.score_p1
            self.score_p2 = self.score_p2
            winner = '*** Congratulations ***'
        else:
            self.score_p2 += 1
            winner = '*** PLAYER TWO WINS ***'
        print(
            f"> Player 1 played : {move1}"
            f"\n> Player 2 played : {move2}"
            f"\n{winner}"
            f"\nScore: Player 1 ( {self.score_p1} ),"
            f"Player 2 ( {self.score_p2} )"
        )
        self.p1.learn(move1, move2)
        self.p2.learn(move2, move1)

    def play_game(self):
        print(
            "\n\n---- Game Start ! ----"
            "\n(If do you want exit game, please digits \'exit\'"
            " when the game will ask you the number of rounds or your move)"
        )
        self.rounds()
        for round in range(int(self.number_rounds)):
            print(
                f"\n\n---------------"
                f"\n -- ROUND {round + 1} --"
                f"\n---------------")
            self.play_round()
        if self.score_p1 == self.score_p2:
            print(
                f"\n------------------------------"
                f"\n-- The Game Ended in a TIE! --"
                f"\n------------------------------"
                f"\nScore: \nPlayer 1 ( {self.score_p1} )"
                f"\nPlayer 2 ( {self.score_p2} )"
            )
        elif self.score_p1 > self.score_p2:
            print(
                f"\n-----------------------------"
                f"\n-- The Summary Of The Game --"
                f"\n-----------------------------"
                f"\n**** PLAYER ONE has WON! ****"
                f"\nScore: \nPlayer 1 ( {self.score_p1} ) --> Winner"
                f"\nPlayer 2 ( {self.score_p2} )"
            )
        else:
            print(
                f"\n-----------------------------"
                f"\n-- The Summary Of The Game --"
                f"\n-----------------------------"
                f"\n\n**** PLAYER TWO has WON! ****"
                f"\nScore: \nPlayer 1: ( {self.score_p1} )"
                f"\nPlayer 2: ( {self.score_p2} ) --> Winner"
            )


if __name__ == '__main__':
    game = Game(HumanPlayer(), random.choice(
        [RandomPlayer(), ReflectPlayer(), CyclePlayer()]))
    game.play_game()
